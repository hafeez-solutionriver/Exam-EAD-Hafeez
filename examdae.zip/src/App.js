import PollDisplay from "./components/PollDisplay";

function App(props) {

  return (
    <div >
  
 <h1>Polling App</h1>
 <PollDisplay/>


    </div>
  );
}

export default App;
