function ThankYouMessage() {
    return ( <h1>Thank You</h1> );
}

export default ThankYouMessage;